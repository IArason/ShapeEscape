#config file containing credentials for rds mysql instance
db_username = "Weaver"
db_password = "homeWorld25"
db_name = "ShapeSouls"